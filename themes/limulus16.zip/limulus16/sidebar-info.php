<aside id="pages_sidebar" class="sidebar page_side no_480 no_320">

	<ul>
		<li class="selected no_480 no_320"><a href="#aviso-privacidad"><?php _e('Aviso de privacidad', 'limulus'); ?></a></li>
		<li><a href="#info-derechos-autor"><?php _e('Información sobre derechos de autor', 'limulus'); ?></a></li>
	</ul>

	
</aside><!-- main_sidebar -->
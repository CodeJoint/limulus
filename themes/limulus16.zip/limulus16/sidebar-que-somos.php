<aside id="pages_sidebar" class="sidebar page_side no_480 no_320">
	<div class="fixed_target">
		<ul>
			<li class="selected"><a href="#sobre_limulus"><?php _e('Sobre Límulus', 'limulus'); ?></a></li>
			<li><a href="#quienes_somos"><?php _e('Quiénes somos', 'limulus'); ?></a></li>
			<li><a href="#nuestros_aliados"><?php _e('Nuestros aliados', 'limulus'); ?></a></li>
			<li><a href="#contactanos"><?php _e('Contáctanos', 'limulus'); ?></a></li>
		</ul>
	</div>

	
</aside><!-- main_sidebar -->

		</div><!-- container -->

	<footer class="main_footer clearfix">
		<a href="<?php echo site_url(); ?>/info/info-derechos-autor/">información sobre derechos de autor</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>|</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:hola@limulus.com">hola@limulus.mx</a>
	</footer>
		<?php wp_footer(); ?>
		<!-- ANALYTICS -->
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-49789320-1', 'limulus.mx');
		  ga('create', 'UA-39817725-1', 'auto', {'name': 'nori'});
		  ga('send', 'pageview');
		  ga('nori.send', 'pageview');


		</script>

	</body>

</html>
